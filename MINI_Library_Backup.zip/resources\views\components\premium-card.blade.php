<div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border-l-4 border-purple-600">
    <div class="p-6 text-gray-900">
        <h3 class="text-lg font-semibold text-purple-800 mb-4">{{ $title }}</h3>
        {{ $slot }}
    </div>
</div>
