<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Borrowing extends Model
{
    const STATUS_PENDING = 'pending';
    const STATUS_APPROVED = 'approved';
    const STATUS_REJECTED = 'rejected';
    const STATUS_RETURN_PENDING = 'return_pending';
    const STATUS_RETURNED = 'returned';

    protected $fillable = [
        'student_id', 
        'book_id', 
        'status',
        'borrowed_at', 
        'due_at', 
        'returned_at', 
        'fine_amount', 
        'is_fine_paid'
    ];

    protected $casts = [
        'borrowed_at' => 'datetime',
        'due_at' => 'datetime',
        'returned_at' => 'datetime',
        'is_fine_paid' => 'boolean',
    ];

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public function book()
    {
        return $this->belongsTo(Book::class);
    }

    public function getCurrentFineAttribute()
    {
        if ($this->is_fine_paid) {
            return 0;
        }

        if ($this->returned_at) {
            return $this->fine_amount;
        }

        if (now() > $this->due_at) {
            $daysOverdue = (int) now()->diffInDays($this->due_at);
            return $daysOverdue * 10;
        }

        return 0;
    }
}
