<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-purple-800 leading-tight">
            {{ __('My Borrowing History') }}
        </h2>
    </x-slot>

    <div class="max-w-7xl mx-auto">
        <x-premium-card title="All Borrowing Records">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-purple-100">
                    <thead class="bg-purple-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Book</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Dates</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Fine Status</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-purple-700 uppercase tracking-wider">Status</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-100">
                        @forelse($borrowings as $borrow)
                            <tr class="hover:bg-purple-50/50 transition-colors">
                                <td class="px-6 py-4">
                                    <div class="text-sm font-bold text-gray-900">{{ $borrow->book->title }}</div>
                                    <div class="text-xs text-purple-500 italic">ISBN: {{ $borrow->book->isbn }}</div>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="text-xs text-gray-600">Borrowed: {{ $borrow->borrowed_at->format('M d, Y') }}</div>
                                    <div class="text-xs font-bold {{ $borrow->returned_at ? 'text-green-600' : (now() > $borrow->due_at ? 'text-red-600' : 'text-amber-600') }}">
                                        Due: {{ $borrow->due_at->format('M d, Y') }}
                                    </div>
                                    @if($borrow->returned_at)
                                        <div class="text-xs text-green-700 italic">Returned: {{ $borrow->returned_at->format('M d, Y') }}</div>
                                    @endif
                                </td>
                                <td class="px-6 py-4">
                                    @if($borrow->current_fine > 0)
                                        <div class="flex flex-col">
                                            <span class="text-sm font-bold text-red-600">₱{{ number_format($borrow->current_fine, 2) }}</span>
                                            @if($borrow->is_fine_paid)
                                                <span class="inline-flex items-center mt-1 px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800 w-fit">Paid</span>
                                            @else
                                                <span class="inline-flex items-center mt-1 px-2 py-0.5 rounded text-xs font-medium bg-red-100 text-red-800 w-fit">Unpaid</span>
                                            @endif
                                        </div>
                                    @else
                                        <span class="text-xs text-gray-400">None</span>
                                    @endif
                                </td>
                                <td class="px-6 py-4">
                                    @php
                                        $statusClasses = [
                                            'pending' => 'bg-amber-100 text-amber-800',
                                            'approved' => 'bg-blue-100 text-blue-800',
                                            'rejected' => 'bg-red-100 text-red-800',
                                            'return_pending' => 'bg-purple-100 text-purple-800',
                                            'returned' => 'bg-green-100 text-green-800',
                                        ];
                                        $statusLabels = [
                                            'pending' => 'Pending Approval',
                                            'approved' => 'Borrowed',
                                            'rejected' => 'Rejected',
                                            'return_pending' => 'Return Pending',
                                            'returned' => 'Returned',
                                        ];
                                    @endphp
                                    <div class="flex flex-col items-end space-y-2">
                                        <span class="px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider {{ $statusClasses[$borrow->status] ?? 'bg-gray-100' }}">
                                            {{ $statusLabels[$borrow->status] ?? $borrow->status }}
                                        </span>
                                        
                                        @if($borrow->status === 'approved')
                                            <form action="{{ route('borrowings.request-return', $borrow) }}" method="POST">
                                                @csrf
                                                <button type="submit" class="text-[10px] font-bold text-purple-600 hover:text-purple-800 underline">Request Return</button>
                                            </form>
                                        @elseif($borrow->status === 'return_pending')
                                            <span class="text-[9px] text-gray-400 italic">Bring to counter</span>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="px-6 py-4 text-center text-gray-500">You have no recorded borrowing history.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            
            <div class="mt-4">
                {{ $borrowings->links() }}
            </div>
        </x-premium-card>
    </div>
</x-app-layout>
