<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-purple-800 leading-tight">
                {{ __('Student History: ') }} {{ $student->name }}
            </h2>
            <a href="{{ route('students.index') }}" class="text-purple-600 hover:text-purple-900 font-bold">← Back to List</a>
        </div>
    </x-slot>

    <div class="space-y-6">
        <x-premium-card title="Student Details">
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <span class="text-gray-500 text-xs uppercase">Email</span>
                    <p class="font-bold">{{ $student->email }}</p>
                </div>
                <div>
                    <span class="text-gray-500 text-xs uppercase">Phone</span>
                    <p class="font-bold">{{ $student->phone ?? 'N/A' }}</p>
                </div>
            </div>
        </x-premium-card>

        <x-premium-card title="Borrowing History">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-purple-100">
                    <thead class="bg-purple-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Book</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Borrowed At</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Due Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Status</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-100">
                        @forelse($student->borrowings as $borrow)
                            <tr>
                                <td class="px-6 py-4 font-medium text-gray-900">{{ $borrow->book->title }}</td>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $borrow->borrowed_at->format('M d, Y') }}</td>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $borrow->due_at->format('M d, Y') }}</td>
                                <td class="px-6 py-4">
                                    @if($borrow->returned_at)
                                        <span class="text-green-600 font-bold">Returned</span>
                                    @else
                                        <span class="text-amber-600 font-bold">In Use</span>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="px-6 py-4 text-center text-gray-500">No history found.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </x-premium-card>
    </div>
</x-app-layout>
