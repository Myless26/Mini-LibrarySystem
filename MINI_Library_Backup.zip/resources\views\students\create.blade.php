<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-purple-800 leading-tight">
            {{ __('Add New Student') }}
        </h2>
    </x-slot>

    <div class="max-w-2xl mx-auto">
        <x-premium-card title="Student Registration">
            <form action="{{ route('students.store') }}" method="POST" class="space-y-6">
                @csrf
                <div>
                    <label class="block text-sm font-medium text-gray-700">Full Name</label>
                    <input type="text" name="name" required class="mt-1 block w-full rounded-md border-purple-200 shadow-sm focus:border-purple-500 focus:ring-purple-500" placeholder="e.g. John Doe">
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Email Address</label>
                        <input type="email" name="email" required class="mt-1 block w-full rounded-md border-purple-200 shadow-sm focus:border-purple-500 focus:ring-purple-500" placeholder="john@example.com">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Phone (Optional)</label>
                        <input type="text" name="phone" class="mt-1 block w-full rounded-md border-purple-200 shadow-sm focus:border-purple-500 focus:ring-purple-500" placeholder="e.g. 09123456789">
                    </div>
                </div>
                <div class="flex items-center justify-end space-x-3 pt-4">
                    <a href="{{ route('students.index') }}" class="text-gray-600 hover:text-gray-900 font-medium">Cancel</a>
                    <button type="submit" class="inline-flex items-center px-6 py-3 bg-purple-600 border border-transparent rounded-lg font-bold text-white uppercase tracking-widest hover:bg-purple-700 shadow-lg active:scale-95 transition-all">
                        Register Student
                    </button>
                </div>
            </form>
        </x-premium-card>
    </div>
</x-app-layout>
