<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-purple-800 leading-tight">
            {{ __('Add New Book') }}
        </h2>
    </x-slot>

    <div class="max-w-3xl mx-auto">
        <x-premium-card title="Book Details">
            <form action="{{ route('books.store') }}" method="POST" class="space-y-6">
                @csrf
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Book Title</label>
                        <input type="text" name="title" required class="mt-1 block w-full rounded-md border-purple-200 shadow-sm focus:border-purple-500 focus:ring-purple-500" placeholder="e.g. Harry Potter">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">ISBN</label>
                        <input type="text" name="isbn" required class="mt-1 block w-full rounded-md border-purple-200 shadow-sm focus:border-purple-500 focus:ring-purple-500" placeholder="e.g. 978-0123456789">
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Select Authors</label>
                    <div class="grid grid-cols-2 md:grid-cols-3 gap-3 max-h-48 overflow-y-auto p-4 border border-purple-100 rounded-lg bg-purple-50/30">
                        @foreach($authors as $author)
                            <label class="flex items-center space-x-2 text-sm text-gray-700 cursor-pointer hover:text-purple-700">
                                <input type="checkbox" name="author_ids[]" value="{{ $author->id }}" class="rounded border-purple-300 text-purple-600 focus:ring-purple-500">
                                <span>{{ $author->name }}</span>
                            </label>
                        @endforeach
                    </div>
                    @error('author_ids')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Initial Stock</label>
                    <input type="number" name="total_stock" value="1" min="1" required class="mt-1 block w-24 rounded-md border-purple-200 shadow-sm focus:border-purple-500 focus:ring-purple-500">
                </div>

                <div class="flex items-center justify-end space-x-3 pt-4">
                    <a href="{{ route('books.index') }}" class="text-gray-600 hover:text-gray-900 font-medium">Cancel</a>
                    <button type="submit" class="inline-flex items-center px-6 py-3 bg-purple-600 border border-transparent rounded-lg font-bold text-white uppercase tracking-widest hover:bg-purple-700 shadow-lg active:scale-95 transition-all">
                        Save Book
                    </button>
                </div>
            </form>
        </x-premium-card>
    </div>
</x-app-layout>
