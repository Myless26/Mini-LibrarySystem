<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-purple-800 leading-tight">
            {{ __('Add New Author') }}
        </h2>
    </x-slot>

    <div class="max-w-2xl mx-auto">
        <x-premium-card title="Author Information">
            <form action="{{ route('authors.store') }}" method="POST" class="space-y-6">
                @csrf
                <div>
                    <label class="block text-sm font-medium text-gray-700">Full Name</label>
                    <input type="text" name="name" required class="mt-1 block w-full rounded-md border-purple-200 shadow-sm focus:border-purple-500 focus:ring-purple-500 transition-colors" placeholder="e.g. J.K. Rowling">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Biography</label>
                    <textarea name="bio" rows="4" class="mt-1 block w-full rounded-md border-purple-200 shadow-sm focus:border-purple-500 focus:ring-purple-500 transition-colors" placeholder="Brief biography..."></textarea>
                </div>
                <div class="flex items-center justify-end space-x-3">
                    <a href="{{ route('authors.index') }}" class="text-gray-600 hover:text-gray-900 font-medium">Cancel</a>
                    <button type="submit" class="inline-flex items-center px-6 py-3 bg-purple-600 border border-transparent rounded-lg font-bold text-white uppercase tracking-widest hover:bg-purple-700 shadow-lg hover:shadow-purple-200 transition-all active:scale-95">
                        Save Author
                    </button>
                </div>
            </form>
        </x-premium-card>
    </div>
</x-app-layout>
