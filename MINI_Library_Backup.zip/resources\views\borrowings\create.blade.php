<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-purple-800 leading-tight">
            {{ __('New Borrowing Transaction') }}
        </h2>
    </x-slot>

    <div class="max-w-2xl mx-auto">
        <x-premium-card title="Borrow Form">
            <form action="{{ route('borrowings.store') }}" method="POST" class="space-y-6">
                @csrf
                @if(auth()->user()->isAdmin())
                <div>
                    <label class="block text-sm font-medium text-gray-700">Select Student</label>
                    <select name="student_id" required class="mt-1 block w-full rounded-md border-purple-200 shadow-sm focus:border-purple-500 focus:ring-purple-500">
                        <option value="">-- Choose Student --</option>
                        @foreach($students as $student)
                            <option value="{{ $student->id }}">{{ $student->name }} ({{ $student->email }})</option>
                        @endforeach
                    </select>
                </div>
                @else
                <input type="hidden" name="student_id" value="{{ auth()->user()->student->id }}">
                <div class="p-4 bg-purple-50 rounded-lg text-purple-800 font-medium">
                    Borrowing as: {{ auth()->user()->name }}
                </div>
                @endif

                <div>
                    <label class="block text-sm font-medium text-gray-700">Select Book</label>
                    <select name="book_id" required class="mt-1 block w-full rounded-md border-purple-200 shadow-sm focus:border-purple-500 focus:ring-purple-500">
                        <option value="">-- Choose Book --</option>
                        @foreach($books as $book)
                            <option value="{{ $book->id }}">{{ $book->title }} (Available: {{ $book->available_stock }})</option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Due Date</label>
                    <input type="date" name="due_at" required min="{{ date('Y-m-d', strtotime('+1 day')) }}" class="mt-1 block w-full rounded-md border-purple-200 shadow-sm focus:border-purple-500 focus:ring-purple-500">
                </div>

                <div class="flex items-center justify-end space-x-3 pt-4">
                    <a href="{{ auth()->user()->isAdmin() ? route('borrowings.index') : route('dashboard') }}" class="text-gray-600 hover:text-gray-900 font-medium">Cancel</a>
                    <button type="submit" class="inline-flex items-center px-6 py-3 bg-purple-600 border border-transparent rounded-lg font-bold text-white uppercase tracking-widest hover:bg-purple-700 shadow-lg active:scale-95 transition-all">
                        Complete Borrowing
                    </button>
                </div>
            </form>
        </x-premium-card>
    </div>
</x-app-layout>
