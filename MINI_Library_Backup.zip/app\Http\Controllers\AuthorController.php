<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AuthorController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $authors = \App\Models\Author::all();
        return view('authors.index', compact('authors'));
    }

    public function create()
    {
        abort_if(!auth()->user()->isAdmin(), 403, 'Unauthorized action.');
        return view('authors.create');
    }

    public function store(Request $request)
    {
        abort_if(!auth()->user()->isAdmin(), 403, 'Unauthorized action.');
        $request->validate([
            'name' => 'required|string|max:255',
            'bio' => 'nullable|string',
        ]);

        \App\Models\Author::create($request->all());

        return redirect()->route('authors.index')->with('success', 'Author created successfully.');
    }

    public function show(\App\Models\Author $author)
    {
        return view('authors.show', compact('author'));
    }

    public function edit(\App\Models\Author $author)
    {
        abort_if(!auth()->user()->isAdmin(), 403, 'Unauthorized action.');
        return view('authors.edit', compact('author'));
    }

    public function update(Request $request, \App\Models\Author $author)
    {
        abort_if(!auth()->user()->isAdmin(), 403, 'Unauthorized action.');
        $request->validate([
            'name' => 'required|string|max:255',
            'bio' => 'nullable|string',
        ]);

        $author->update($request->all());

        return redirect()->route('authors.index')->with('success', 'Author updated successfully.');
    }

    public function destroy(\App\Models\Author $author)
    {
        abort_if(!auth()->user()->isAdmin(), 403, 'Unauthorized action.');
        $author->delete();
        return redirect()->route('authors.index')->with('success', 'Author deleted successfully.');
    }
}
