<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MyBorrowingController extends Controller
{
    public function index()
    {
        $student = auth()->user()->student;
        
        if (!$student) {
            return redirect()->route('dashboard')->with('error', 'Student profile not found.');
        }

        $borrowings = $student->borrowings()
            ->with('book')
            ->latest()
            ->paginate(15);

        return view('my-borrowings.index', compact('borrowings'));
    }
}
