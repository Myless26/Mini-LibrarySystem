<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Mini Library Management System</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=inter:400,600,700,800&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])

        <style>
            body {
                font-family: 'Inter', sans-serif;
            }
            .bg-purple-premium {
                background: linear-gradient(135deg, #4c1d95 0%, #6b21a8 50%, #7e22ce 100%);
            }
            .glass {
                background: rgba(255, 255, 255, 0.1);
                backdrop-filter: blur(15px);
                border: 1px solid rgba(255, 255, 255, 0.2);
            }
            .floating {
                animation: floating 3s ease-in-out infinite;
            }
            @keyframes floating {
                0% { transform: translateY(0px); }
                50% { transform: translateY(-10px); }
                100% { transform: translateY(0px); }
            }
        </style>
    </head>
    <body class="antialiased bg-purple-premium min-h-screen flex items-center justify-center text-white overflow-hidden">
        <div class="relative z-10 max-w-4xl px-6 text-center">
            <div class="mb-8 inline-block p-4 rounded-2xl glass floating border-purple-500 shadow-[0_0_30px_rgba(168,85,247,0.4)]">
                <x-application-logo class="w-16 h-16 drop-shadow-xl" />
            </div>
            
            <h1 class="text-5xl md:text-7xl font-black tracking-tight mb-4">
                Mini <span class="text-purple-300">LMS</span>
            </h1>
            <p class="text-xl md:text-2xl text-purple-100 mb-10 max-w-2xl mx-auto leading-relaxed">
                A modern, intuitive platform built for managing your library inventory, student records, and automated fine computation with style.
            </p>

            <div class="flex flex-col sm:flex-row items-center justify-center gap-4">
                @if (Route::has('login'))
                    @auth
                        <a href="{{ url('/dashboard') }}" class="px-8 py-4 bg-white text-purple-900 font-bold rounded-xl shadow-2xl hover:bg-purple-50 transition-all hover:scale-105 active:scale-95">
                            Enter Dashboard →
                        </a>
                    @else
                        <a href="{{ route('login') }}" class="px-8 py-4 bg-white text-purple-900 font-bold rounded-xl shadow-2xl hover:bg-purple-50 transition-all hover:scale-105 active:scale-95">
                            Log In
                        </a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}" class="px-8 py-4 glass text-white font-bold rounded-xl hover:bg-white/20 transition-all">
                                Sign Up
                            </a>
                        @endif
                    @endauth
                @endif
            </div>

            <div class="mt-20 flex justify-center gap-8 opacity-50 text-sm font-medium">
                <span>Fast Performance</span>
                <span>•</span>
                <span>Purple Aesthetic</span>
                <span>•</span>
                <span>Smart Fines</span>
            </div>
        </div>

        <!-- Decorative circles -->
        <div class="absolute top-0 -left-20 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse"></div>
        <div class="absolute bottom-0 -right-20 w-96 h-96 bg-fuchsia-500 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse"></div>
    </body>
</html>
