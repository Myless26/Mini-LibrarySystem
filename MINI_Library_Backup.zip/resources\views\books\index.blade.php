<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-purple-800 leading-tight">
                {{ __('Books Inventory') }}
            </h2>
            @if(auth()->check() && auth()->user()->isAdmin())
            <a href="{{ route('books.create') }}" class="inline-flex items-center px-4 py-2 bg-purple-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-purple-700 shadow-lg transition-all">
                + Add Book
            </a>
            @endif
        </div>
    </x-slot>

    <x-premium-card title="Manage Books">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-purple-100">
                <thead class="bg-purple-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Book Info</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Authors</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Stock Status</th>
                        @if(auth()->check() && auth()->user()->isAdmin())
                        <th class="px-6 py-3 text-right text-xs font-medium text-purple-700 uppercase tracking-wider">Actions</th>
                        @endif
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-100">
                    @forelse($books as $book)
                        <tr class="hover:bg-purple-50/50 transition-colors">
                            <td class="px-6 py-4">
                                <div class="text-sm font-bold text-gray-900">{{ $book->title }}</div>
                                <div class="text-xs text-gray-500">ISBN: {{ $book->isbn }}</div>
                            </td>
                            <td class="px-6 py-4">
                                @foreach($book->authors as $author)
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800 mb-1">
                                        {{ $author->name }}
                                    </span>
                                @endforeach
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex items-center">
                                    <div class="text-sm text-gray-900 mr-2">{{ $book->available_stock }} / {{ $book->total_stock }}</div>
                                    <div class="w-24 bg-gray-200 rounded-full h-1.5 dark:bg-gray-700">
                                        <div class="bg-purple-600 h-1.5 rounded-full" style="width: {{ ($book->available_stock / max($book->total_stock, 1)) * 100 }}%"></div>
                                    </div>
                                </div>
                            </td>
                            @if(auth()->check() && auth()->user()->isAdmin())
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <a href="{{ route('books.edit', $book) }}" class="text-purple-600 hover:text-purple-900 mr-3">Edit</a>
                                <form x-data action="{{ route('books.destroy', $book) }}" method="POST" class="inline" x-ref="deleteForm{{ $book->id }}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="button" class="text-red-600 hover:text-red-900" 
                                            @click="$dispatch('confirm', { 
                                                title: 'Delete Book?', 
                                                message: 'Removing \'{{ $book->title }}\' from inventory. Continue?',
                                                action: () => $refs.deleteForm{{ $book->id }}.submit()
                                            })">
                                        Delete
                                    </button>
                                </form>
                            </td>
                            @endif
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4" class="px-6 py-4 text-center text-gray-500">No books in inventory.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </x-premium-card>
</x-app-layout>
