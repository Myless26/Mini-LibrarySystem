<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BorrowingController extends Controller
{
    public function index()
    {
        $borrowings = \App\Models\Borrowing::with(['student', 'book'])->latest()->get();
        return view('borrowings.index', compact('borrowings'));
    }

    public function create()
    {
        $students = \App\Models\Student::all();
        $books = \App\Models\Book::where('available_stock', '>', 0)->get();
        return view('borrowings.create', compact('students', 'books'));
    }

    public function store(Request $request)
    {
        // Only students can request to borrow
        if (!auth()->user()->isStudent() && !auth()->user()->isAdmin()) {
            abort(403);
        }

        $request->validate([
            'book_id' => 'required|exists:books,id',
            'due_at' => 'required|date|after:today',
        ]);

        // If admin is doing it for a student (from the admin panel)
        $studentId = $request->student_id;
        
        // If student is doing it themselves
        if (auth()->user()->isStudent()) {
            $studentId = auth()->user()->student->id;
        }

        if (!$studentId) {
            return back()->with('error', 'Student profile not found.');
        }

        $book = \App\Models\Book::findOrFail($request->book_id);
        
        if ($book->available_stock <= 0) {
            return back()->with('error', 'Book is currently out of stock.');
        }

        $borrowing = \App\Models\Borrowing::create([
            'student_id' => $studentId,
            'book_id' => $request->book_id,
            'status' => \App\Models\Borrowing::STATUS_PENDING,
            'due_at' => $request->due_at,
        ]);

        // Notify Admins about the new request
        $admins = \App\Models\User::where('role', 'admin')->get();
        // We'll update the notification message later or use a generic one
        \Illuminate\Support\Facades\Notification::send($admins, new \App\Notifications\BookBorrowedNotification($borrowing));

        return redirect()->route(auth()->user()->isAdmin() ? 'borrowings.index' : 'dashboard')
            ->with('success', 'Borrowing request submitted. Waiting for Admin approval.');
    }

    public function approve(\App\Models\Borrowing $borrowing)
    {
        abort_if(!auth()->user()->isAdmin(), 403);

        if ($borrowing->status !== \App\Models\Borrowing::STATUS_PENDING) {
            return back()->with('error', 'Request is not in pending status.');
        }

        if ($borrowing->book->available_stock <= 0) {
            return back()->with('error', 'Book is out of stock.');
        }

        $borrowing->update([
            'status' => \App\Models\Borrowing::STATUS_APPROVED,
            'borrowed_at' => now(),
        ]);

        $borrowing->book->decrement('available_stock');

        // Notify Student
        $studentUser = $borrowing->student->user;
        if ($studentUser) {
            $studentUser->notify(new \App\Notifications\BookBorrowedNotification($borrowing));
        }

        return back()->with('success', 'Borrowing request approved!');
    }

    public function reject(\App\Models\Borrowing $borrowing)
    {
        abort_if(!auth()->user()->isAdmin(), 403);

        $borrowing->update(['status' => \App\Models\Borrowing::STATUS_REJECTED]);

        return back()->with('success', 'Borrowing request rejected.');
    }

    public function requestReturn(\App\Models\Borrowing $borrowing)
    {
        // Only the student who borrowed it can request return
        if (auth()->user()->isStudent() && $borrowing->student_id !== auth()->user()->student->id) {
            abort(403);
        }

        if ($borrowing->status !== \App\Models\Borrowing::STATUS_APPROVED) {
            return back()->with('error', 'Cannot return this item.');
        }

        $borrowing->update(['status' => \App\Models\Borrowing::STATUS_RETURN_PENDING]);

        // Notify Admins
        $admins = \App\Models\User::where('role', 'admin')->get();
        \Illuminate\Support\Facades\Notification::send($admins, new \App\Notifications\BookReturnedNotification($borrowing));

        return back()->with('success', 'Return request sent. Please bring the book to the counter.');
    }

    public function acknowledgeReturn(\App\Models\Borrowing $borrowing)
    {
        abort_if(!auth()->user()->isAdmin(), 403);

        if ($borrowing->status !== \App\Models\Borrowing::STATUS_RETURN_PENDING) {
            // Allow admin to return directly if needed (legacy or manual)
            if ($borrowing->status !== \App\Models\Borrowing::STATUS_APPROVED) {
                 return back()->with('error', 'Invalid return action.');
            }
        }

        $returnedAt = now();
        $dueAt = $borrowing->due_at;
        $fine = 0;

        if ($returnedAt > $dueAt) {
            $daysOverdue = (int) $returnedAt->diffInDays($dueAt);
            $fine = $daysOverdue * 10;
        }

        $borrowing->update([
            'status' => \App\Models\Borrowing::STATUS_RETURNED,
            'returned_at' => $returnedAt,
            'fine_amount' => $fine,
        ]);

        $borrowing->book->increment('available_stock');

        // Notify Student
        $studentUser = $borrowing->student->user;
        if ($studentUser) {
            $studentUser->notify(new \App\Notifications\BookReturnedNotification($borrowing));
        }

        return back()->with('success', 'Return acknowledged and stock updated.');
    }

    public function payFine(\App\Models\Borrowing $borrowing)
    {
        $borrowing->update(['is_fine_paid' => true]);
        return back()->with('success', 'Fine paid successfully.');
    }
}
