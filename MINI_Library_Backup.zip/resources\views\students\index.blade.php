<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-purple-800 leading-tight">
                {{ __('Student Directory') }}
            </h2>
            <a href="{{ route('students.create') }}" class="inline-flex items-center px-4 py-2 bg-purple-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-purple-700 shadow-lg transition-all">
                + Add Student
            </a>
        </div>
    </x-slot>

    <x-premium-card title="Registered Students">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-purple-100">
                <thead class="bg-purple-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Student Info</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Phone</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-purple-700 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-100">
                    @forelse($students as $student)
                        <tr class="hover:bg-purple-50/50 transition-colors">
                            <td class="px-6 py-4">
                                <div class="text-sm font-bold text-gray-900">{{ $student->name }}</div>
                                <div class="text-xs text-gray-500">{{ $student->email }}</div>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-600">{{ $student->phone ?? 'N/A' }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <a href="{{ route('students.show', $student) }}" class="text-blue-600 hover:text-blue-900 mr-3">History</a>
                                <a href="{{ route('students.edit', $student) }}" class="text-purple-600 hover:text-purple-900 mr-3">Edit</a>
                                <form x-data action="{{ route('students.destroy', $student) }}" method="POST" class="inline" x-ref="deleteForm{{ $student->id }}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="button" class="text-red-600 hover:text-red-900" 
                                            @click="$dispatch('confirm', { 
                                                title: 'Delete Student?', 
                                                message: 'Deregistering {{ $student->name }}. This action is permanent. Continue?',
                                                action: () => $refs.deleteForm{{ $student->id }}.submit()
                                            })">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="3" class="px-6 py-4 text-center text-gray-500">No students found.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </x-premium-card>
</x-app-layout>
