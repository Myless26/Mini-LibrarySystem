<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Author;
use App\Models\Book;
use App\Models\Student;
use App\Models\Borrowing;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Admin User
        User::factory()->create([
            'name' => 'Librarian Admin',
            'email' => 'admin@lms.com',
            'password' => Hash::make('Admin@Lib2026!'),
            'role' => 'admin',
        ]);

        // Authors
        $authors = [
            ['name' => 'J.K. Rowling', 'bio' => 'English author, best known for the Harry Potter series.'],
            ['name' => 'George R.R. Martin', 'bio' => 'American novelist and short story writer in the fantasy, horror, and science fiction genres.'],
            ['name' => 'F. Scott Fitzgerald', 'bio' => 'American novelist, essayist, and short story writer.'],
        ];

        foreach ($authors as $auth) {
            Author::create($auth);
        }

        // Books
        $books = [
            ['title' => 'Harry Potter and the Philosopher\'s Stone', 'isbn' => '9780747532699', 'total_stock' => 5, 'available_stock' => 5],
            ['title' => 'A Game of Thrones', 'isbn' => '9780553103540', 'total_stock' => 3, 'available_stock' => 3],
            ['title' => 'The Great Gatsby', 'isbn' => '9780743273565', 'total_stock' => 10, 'available_stock' => 10],
        ];

        foreach ($books as $bk) {
            $book = Book::create($bk);
            $book->authors()->attach(rand(1, 3));
        }

        // Students
        $students = [
            ['name' => 'Alice Cooper', 'email' => 'alice@example.com', 'phone' => '09123456781'],
            ['name' => 'Bob Marley', 'email' => 'bob@example.com', 'phone' => '09123456782'],
            ['name' => 'Charlie Puth', 'email' => 'charlie@example.com', 'phone' => '09123456783'],
        ];

        foreach ($students as $stu) {
            $user = User::factory()->create([
                'name' => $stu['name'],
                'email' => $stu['email'],
                'password' => Hash::make('studentpassword123'),
                'role' => 'student',
            ]);
            
            $stu['user_id'] = $user->id;
            Student::create($stu);
        }
    }
}
