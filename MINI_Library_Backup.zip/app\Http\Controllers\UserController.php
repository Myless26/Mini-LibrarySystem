<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        abort_if(!auth()->user()->isAdmin(), 403, 'Unauthorized action.');
        
        $users = User::latest()->paginate(15);
        return view('users.index', compact('users'));
    }
}
