<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use App\Models\Borrowing;

class BookBorrowedNotification extends Notification
{
    use Queueable;

    public $borrowing;

    public function __construct(Borrowing $borrowing)
    {
        $this->borrowing = $borrowing;
    }

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toDatabase(object $notifiable): array
    {
        $actor = $this->borrowing->student->name;
        $book = $this->borrowing->book->title;
        $status = $this->borrowing->status;
        
        $title = $status === Borrowing::STATUS_PENDING ? 'New Borrowing Request' : 'Borrowing Approved';
        $message = $status === Borrowing::STATUS_PENDING 
            ? "{$actor} requested to borrow '{$book}'."
            : "Your request to borrow '{$book}' has been approved! Due on {$this->borrowing->due_at->format('M d, Y')}.";

        return [
            'title' => $title,
            'message' => $message,
            'action_url' => route(auth()->user() && auth()->user()->isAdmin() ? 'borrowings.index' : 'my-borrowings.index'),
            'icon' => $status === Borrowing::STATUS_PENDING ? 'clock' : 'check-circle'
        ];
    }
}
