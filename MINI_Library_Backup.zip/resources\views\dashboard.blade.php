<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-purple-800 leading-tight">
                {{ __('Library Dashboard') }}
            </h2>
            <div class="flex items-center space-x-2 bg-green-50 px-3 py-1 rounded-full border border-green-100">
                <span class="relative flex h-2 w-2">
                  <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span class="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
                <span class="text-[10px] font-bold text-green-700 uppercase tracking-widest">Live System Data</span>
            </div>
        </div>
    </x-slot>

    @if(auth()->check() && auth()->user()->isAdmin())
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {{-- Total Books Card --}}
        <a href="{{ route('books.index') }}" class="block bg-purple-premium p-6 rounded-2xl shadow-xl text-white transform hover:scale-105 transition-all outline-none focus:ring-4 focus:ring-purple-300">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-purple-100 text-sm uppercase font-bold tracking-wider">Total Books</p>
                    <h3 class="text-3xl font-black mt-1">{{ \App\Models\Book::sum('total_stock') }}</h3>
                </div>
                <div class="p-3 bg-white/20 rounded-xl">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 15 15C18.168 18.477 19.754 18 21.5 18s3.332.477 4.5 1.253v13C22.832 19.523 21.246 20 19.5 20s-3.332-.477-4.5-1.253z"></path></svg>
                </div>
            </div>
            <div class="mt-4 text-purple-200 text-xs flex justify-between items-center">
                <span>Different Titles: {{ \App\Models\Book::count() }}</span>
                <span class="font-bold underline">Manage →</span>
            </div>
        </a>

        {{-- Available Stock Card --}}
        <a href="{{ route('books.index') }}" class="block bg-indigo-600 p-6 rounded-2xl shadow-xl text-white transform hover:scale-105 transition-all outline-none focus:ring-4 focus:ring-indigo-300">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-indigo-100 text-sm uppercase font-bold tracking-wider">Available</p>
                    <h3 class="text-3xl font-black mt-1">{{ \App\Models\Book::sum('available_stock') }}</h3>
                </div>
                <div class="p-3 bg-white/20 rounded-xl">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
            </div>
            <div class="mt-4 text-indigo-200 text-xs flex justify-between items-center">
                <span>{{ \App\Models\Borrowing::whereIn('status', ['approved', 'return_pending'])->count() }} Out of Library</span>
                <span class="font-bold underline">Inventory →</span>
            </div>
        </a>

        {{-- Registered Students --}}
        <a href="{{ route('students.index') }}" class="block bg-violet-600 p-6 rounded-2xl shadow-xl text-white transform hover:scale-105 transition-all outline-none focus:ring-4 focus:ring-violet-300">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-violet-100 text-sm uppercase font-bold tracking-wider">Students</p>
                    <h3 class="text-3xl font-black mt-1">{{ \App\Models\Student::count() }}</h3>
                </div>
                <div class="p-3 bg-white/20 rounded-xl">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                </div>
            </div>
            <div class="mt-4 text-violet-200 text-xs flex justify-between items-center">
                <span>Growing community!</span>
                <span class="font-bold underline">Directory →</span>
            </div>
        </a>

        {{-- Pending Fines --}}
        <a href="{{ route('borrowings.index') }}" class="block bg-fuchsia-600 p-6 rounded-2xl shadow-xl text-white transform hover:scale-105 transition-all outline-none focus:ring-4 focus:ring-fuchsia-300">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-fuchsia-100 text-sm uppercase font-bold tracking-wider">System Fines</p>
                    <h3 class="text-3xl font-black mt-1">₱{{ number_format(\App\Models\Borrowing::where('is_fine_paid', false)->get()->sum('current_fine'), 2) }}</h3>
                </div>
                <div class="p-3 bg-white/20 rounded-xl">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
            </div>
            <div class="mt-4 text-fuchsia-200 text-xs flex justify-between items-center">
                <span>{{ \App\Models\Borrowing::whereIn('status', ['pending', 'return_pending'])->count() }} Urgent Requests</span>
                <span class="font-bold underline">Action Items →</span>
            </div>
        </a>
    </div>

    <div class="mt-10 grid grid-cols-1 lg:grid-cols-2 gap-10">
        <x-premium-card title="System Activity Tracker">
            <div class="space-y-4">
                @foreach(\App\Models\Borrowing::with(['student', 'book'])->latest()->take(6)->get() as $recent)
                    <div class="flex items-center justify-between border-b border-purple-50 pb-2">
                        <div>
                            <div class="text-sm">
                                <span class="font-black text-gray-800">{{ $recent->student->name }}</span>
                                <span class="text-gray-400 text-[10px] uppercase font-bold mx-1">↔</span>
                                <span class="font-black text-purple-700">{{ $recent->book->title }}</span>
                            </div>
                            <div class="text-[9px] text-gray-400 font-medium">
                                {{ $recent->created_at->diffForHumans() }}
                            </div>
                        </div>
                        <div class="text-right">
                            @php
                                $statusTags = [
                                    'pending' => ['label' => 'REQUEST', 'color' => 'bg-amber-100 text-amber-700'],
                                    'approved' => ['label' => 'BORROWED', 'color' => 'bg-blue-100 text-blue-700'],
                                    'rejected' => ['label' => 'DENIED', 'color' => 'bg-red-100 text-red-700'],
                                    'return_pending' => ['label' => 'RETURNING', 'color' => 'bg-purple-100 text-purple-700'],
                                    'returned' => ['label' => 'CLOSED', 'color' => 'bg-green-100 text-green-700'],
                                ];
                                $tag = $statusTags[$recent->status] ?? ['label' => 'UNKNOWN', 'color' => 'bg-gray-100 text-gray-700'];
                            @endphp
                            <span class="px-2 py-0.5 rounded text-[8px] font-black tracking-widest {{ $tag['color'] }}">
                                {{ $tag['label'] }}
                            </span>
                        </div>
                    </div>
                @endforeach
                @if(\App\Models\Borrowing::count() == 0)
                    <p class="text-center text-gray-500 italic py-4">No system activities recorded.</p>
                @endif
            </div>
            <div class="mt-4 text-center">
                 <a href="{{ route('borrowings.index') }}" class="text-[10px] font-bold text-purple-600 hover:underline uppercase tracking-widest">Full Audit Log →</a>
            </div>
        </x-premium-card>

        <x-premium-card title="Administrative Cockpit">
             <div class="grid grid-cols-2 gap-4">
                <a href="{{ route('books.create') }}" class="p-4 bg-purple-50 rounded-xl border border-purple-100 hover:bg-purple-100 transition-colors text-center group">
                    <span class="block font-black text-purple-800 group-hover:scale-110 transition-transform">ADD NEW BOOK</span>
                    <span class="text-[10px] text-purple-400">Inventory Management</span>
                </a>
                <a href="{{ route('students.create') }}" class="p-4 bg-purple-50 rounded-xl border border-purple-100 hover:bg-purple-100 transition-colors text-center group">
                    <span class="block font-black text-purple-800 group-hover:scale-110 transition-transform">ENROLL STUDENT</span>
                    <span class="text-[10px] text-purple-400">Member Registration</span>
                </a>
                <a href="{{ route('borrowings.index') }}" class="p-4 bg-purple-50 rounded-xl border border-purple-100 hover:bg-purple-100 transition-colors text-center group">
                    <span class="block font-black text-purple-800 group-hover:scale-110 transition-transform">QUEUED TASKS</span>
                    <span class="text-[10px] text-purple-400">{{ \App\Models\Borrowing::whereIn('status', ['pending', 'return_pending'])->count() }} Actions Required</span>
                </a>
                <a href="{{ route('archive.index') }}" class="p-4 bg-purple-50 rounded-xl border border-purple-100 hover:bg-purple-100 transition-colors text-center group">
                    <span class="block font-black text-purple-800 group-hover:scale-110 transition-transform">ARCHIVE VAULT</span>
                    <span class="text-[10px] text-purple-400">Soft Deletes & Recovery</span>
                </a>
             </div>
        </x-premium-card>
    </div>
    @elseif(auth()->check() && auth()->user()->isStudent())
    {{-- Student Dashboard remains as updated before but I'll ensure it stays consistent with the new nomenclature --}}
    @php
        $student = auth()->user()->student;
        $activeBorrowingsCount = $student ? $student->borrowings()->whereIn('status', ['approved', 'return_pending'])->count() : 0;
        $pendingFines = $student ? $student->borrowings()->where('is_fine_paid', false)->get()->sum('current_fine') : 0;
        $borrowings = $student ? $student->borrowings()->with('book')->latest()->take(5)->get() : collect();
    @endphp
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <a href="{{ route('books.index') }}" class="block bg-purple-premium p-6 rounded-2xl shadow-xl text-white transform hover:scale-105 transition-all outline-none">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-purple-100 text-sm uppercase font-bold tracking-wider">Library Books</p>
                    <h3 class="text-3xl font-black mt-1">{{ \App\Models\Book::sum('available_stock') }}</h3>
                </div>
                <div class="p-3 bg-white/20 rounded-xl">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 15 15C18.168 18.477 19.754 18 21.5 18s3.332.477 4.5 1.253v13C22.832 19.523 21.246 20 19.5 20s-3.332-.477-4.5-1.253z"></path></svg>
                </div>
            </div>
            <div class="mt-4 text-purple-200 text-xs flex justify-between items-center">
                <span>Available now!</span>
                <span class="font-bold underline">Browse →</span>
            </div>
        </a>

        <a href="{{ route('my-borrowings.index') }}" class="block bg-indigo-600 p-6 rounded-2xl shadow-xl text-white transform hover:scale-105 transition-all outline-none">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-indigo-100 text-sm uppercase font-bold tracking-wider">In My Pocket</p>
                    <h3 class="text-3xl font-black mt-1">{{ $activeBorrowingsCount }}</h3>
                </div>
                <div class="p-3 bg-white/20 rounded-xl">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
            </div>
            <div class="mt-4 text-indigo-200 text-xs flex justify-between items-center">
                <span>Total history: {{ $student ? $student->borrowings()->count() : 0 }}</span>
                <span class="font-bold underline">Timeline →</span>
            </div>
        </a>

        <a href="{{ route('my-borrowings.index') }}" class="block bg-fuchsia-600 p-6 rounded-2xl shadow-xl text-white transform hover:scale-105 transition-all outline-none">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-fuchsia-100 text-sm uppercase font-bold tracking-wider">Unpaid Fines</p>
                    <h3 class="text-3xl font-black mt-1">₱{{ number_format($pendingFines, 2) }}</h3>
                </div>
                <div class="p-3 bg-white/20 rounded-xl">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
            </div>
            <div class="mt-4 text-fuchsia-200 text-xs flex justify-between items-center">
                <span>Settle with Librarian</span>
                <span class="font-bold underline">Payment Info →</span>
            </div>
        </a>
    </div>

    <div class="mt-10 grid grid-cols-1 lg:grid-cols-2 gap-10">
        <x-premium-card title="My Recent Books">
            <div class="space-y-4">
                @forelse($borrowings as $recent)
                    <div class="flex items-center justify-between border-b border-purple-50 pb-2">
                        <div>
                            <p class="font-bold text-gray-800 text-sm">{{ $recent->book->title }}</p>
                            <p class="text-[9px] text-gray-400">{{ $recent->status === 'returned' ? 'Returned ' . $recent->returned_at->diffForHumans() : 'Borrowed ' . $recent->borrowed_at->diffForHumans() }}</p>
                        </div>
                        <div class="text-right">
                             @php
                                $sTags = [
                                    'pending' => ['label' => 'WAIT APPROVAL', 'color' => 'bg-amber-100 text-amber-700'],
                                    'approved' => ['label' => 'CURRENT', 'color' => 'bg-blue-100 text-blue-700'],
                                    'rejected' => ['label' => 'NOT ALLOWED', 'color' => 'bg-red-100 text-red-700'],
                                    'return_pending' => ['label' => 'HANDING OVER', 'color' => 'bg-purple-100 text-purple-700'],
                                    'returned' => ['label' => 'RETURNED', 'color' => 'bg-green-100 text-green-700'],
                                ];
                                $st = $sTags[$recent->status] ?? ['label' => '...', 'color' => 'bg-gray-100 text-gray-700'];
                            @endphp
                            <span class="px-2 py-0.5 rounded text-[8px] font-black tracking-widest {{ $st['color'] }}">
                                {{ $st['label'] }}
                            </span>
                        </div>
                    </div>
                @empty
                    <p class="text-center text-gray-500 italic py-4">No recent library activities.</p>
                @endforelse
            </div>
        </x-premium-card>

        <x-premium-card title="Quick Actions">
             <div class="grid grid-cols-2 gap-4">
                <a href="{{ route('books.index') }}" class="p-4 bg-purple-50 rounded-xl border border-purple-100 hover:bg-purple-100 transition-colors text-center group">
                    <span class="block font-black text-purple-800 group-hover:scale-110 transition-transform">EXPLORE</span>
                    <span class="text-[10px] text-purple-400">Discover new Reads</span>
                </a>
                <a href="{{ route('my-borrowings.index') }}" class="p-4 bg-purple-50 rounded-xl border border-purple-100 hover:bg-purple-100 transition-colors text-center group">
                    <span class="block font-black text-purple-800 group-hover:scale-110 transition-transform">MY ACCOUNT</span>
                    <span class="text-[10px] text-purple-400">Manage your loans</span>
                </a>
             </div>
        </x-premium-card>
    </div>
    @endif
</x-app-layout>
