<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = \App\Models\Book::with('authors');

        if ($request->has('search')) {
            $search = $request->get('search');
            $query->where('title', 'like', "%{$search}%")
                  ->orWhere('isbn', 'like', "%{$search}%");
        }

        $books = $query->get();
        return view('books.index', compact('books'));
    }

    public function create()
    {
        abort_if(!auth()->user()->isAdmin(), 403, 'Unauthorized action.');
        $authors = \App\Models\Author::all();
        return view('books.create', compact('authors'));
    }

    public function store(Request $request)
    {
        abort_if(!auth()->user()->isAdmin(), 403, 'Unauthorized action.');
        $request->validate([
            'title' => 'required|string|max:255',
            'isbn' => 'required|string|unique:books,isbn',
            'total_stock' => 'required|integer|min:0',
            'author_ids' => 'required|array',
            'author_ids.*' => 'exists:authors,id',
        ]);

        $book = \App\Models\Book::create([
            'title' => $request->title,
            'isbn' => $request->isbn,
            'total_stock' => $request->total_stock,
            'available_stock' => $request->total_stock,
        ]);

        $book->authors()->attach($request->author_ids);

        return redirect()->route('books.index')->with('success', 'Book created successfully.');
    }

    public function show(\App\Models\Book $book)
    {
        return view('books.show', compact('book'));
    }

    public function edit(\App\Models\Book $book)
    {
        abort_if(!auth()->user()->isAdmin(), 403, 'Unauthorized action.');
        $authors = \App\Models\Author::all();
        return view('books.edit', compact('book', 'authors'));
    }

    public function update(Request $request, \App\Models\Book $book)
    {
        abort_if(!auth()->user()->isAdmin(), 403, 'Unauthorized action.');
        $request->validate([
            'title' => 'required|string|max:255',
            'isbn' => 'required|string|unique:books,isbn,' . $book->id,
            'total_stock' => 'required|integer|min:0',
            'author_ids' => 'required|array',
            'author_ids.*' => 'exists:authors,id',
        ]);

        $diff = $request->total_stock - $book->total_stock;
        
        $book->update([
            'title' => $request->title,
            'isbn' => $request->isbn,
            'total_stock' => $request->total_stock,
            'available_stock' => $book->available_stock + $diff,
        ]);

        $book->authors()->sync($request->author_ids);

        return redirect()->route('books.index')->with('success', 'Book updated successfully.');
    }

    public function destroy(\App\Models\Book $book)
    {
        abort_if(!auth()->user()->isAdmin(), 403, 'Unauthorized action.');
        $book->delete();
        return redirect()->route('books.index')->with('success', 'Book deleted successfully.');
    }
}
