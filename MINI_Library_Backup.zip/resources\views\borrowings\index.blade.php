<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-purple-800 leading-tight">
                {{ __('Borrowing Management') }}
            </h2>
            <a href="{{ route('borrowings.create') }}" class="inline-flex items-center px-4 py-2 bg-purple-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-purple-700 shadow-lg transition-all">
                + New Borrow
            </a>
        </div>
    </x-slot>

    <div class="space-y-6">
        @php
            $pending = $borrowings->whereIn('status', ['pending', 'return_pending']);
            $history = $borrowings->whereNotIn('status', ['pending', 'return_pending']);
        @endphp

        {{-- Pending Actions Section --}}
        @if($pending->count() > 0)
        <x-premium-card title="Action Required (Pending Requests)">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-purple-100">
                    <thead class="bg-amber-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-bold text-amber-700 uppercase">Request Details</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-amber-700 uppercase">Status</th>
                            <th class="px-6 py-3 text-right text-xs font-bold text-amber-700 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-100">
                        @foreach($pending as $borrow)
                            <tr class="hover:bg-amber-50/30 transition-colors">
                                <td class="px-6 py-4">
                                    <div class="flex items-center space-x-3">
                                        <div class="flex-shrink-0 h-10 w-10 bg-purple-100 rounded-full flex items-center justify-center">
                                            <i class="fas fa-exchange-alt text-purple-600"></i>
                                        </div>
                                        <div>
                                            <div class="text-sm">
                                                <span class="font-black text-gray-900">{{ $borrow->student->name }}</span>
                                                <span class="text-gray-500">wants to borrow</span>
                                                <span class="font-black text-purple-700">{{ $borrow->book->title }}</span>
                                            </div>
                                            <div class="text-[10px] text-gray-500">Requested for: {{ $borrow->due_at->format('M d, Y') }}</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="px-2 py-1 rounded-full text-[10px] font-bold uppercase {{ $borrow->status === 'pending' ? 'bg-amber-100 text-amber-800' : 'bg-purple-100 text-purple-800' }}">
                                        {{ $borrow->status === 'pending' ? 'Borrow Request' : 'Return Request' }}
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-right">
                                    <div class="flex justify-end space-x-2">
                                        @if($borrow->status === 'pending')
                                            <form action="{{ route('borrowings.approve', $borrow) }}" method="POST">
                                                @csrf
                                                <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-[10px] font-bold shadow-sm transition-all">APPROVE</button>
                                            </form>
                                            <form action="{{ route('borrowings.reject', $borrow) }}" method="POST">
                                                @csrf
                                                <button type="submit" class="bg-red-100 text-red-600 hover:bg-red-200 px-3 py-1 rounded text-[10px] font-bold transition-all">REJECT</button>
                                            </form>
                                        @else
                                            <form action="{{ route('borrowings.acknowledge-return', $borrow) }}" method="POST">
                                                @csrf
                                                <button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white px-4 py-1 rounded text-[10px] font-bold shadow-sm transition-all uppercase">Acknowledge Return</button>
                                            </form>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </x-premium-card>
        @endif

        {{-- Transaction History Section --}}
        <x-premium-card title="Borrowing History & Inventory Tracking">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-purple-100">
                    <thead class="bg-purple-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Relationship (Who & What)</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Metrics & Fines</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-purple-700 uppercase tracking-wider">System Control</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-100">
                        @forelse($history as $borrow)
                            <tr class="hover:bg-purple-50/50 transition-colors">
                                <td class="px-6 py-4">
                                    <div class="flex flex-col">
                                        <div class="text-sm font-bold text-gray-900">{{ $borrow->book->title }}</div>
                                        <div class="text-[11px] text-gray-600">
                                            <span class="italic">By:</span> <span class="font-medium">{{ $borrow->student->name }}</span>
                                        </div>
                                        <div class="text-[9px] text-purple-400 mt-0.5">ISBN: {{ $borrow->book->isbn }}</div>
                                    </div>
                                </td>
                                <td class="px-6 py-4">
                                    @php
                                        $statusClasses = [
                                            'approved' => 'bg-blue-100 text-blue-800',
                                            'rejected' => 'bg-gray-100 text-gray-800',
                                            'returned' => 'bg-green-100 text-green-800',
                                        ];
                                        $statusLabels = [
                                            'approved' => 'Currently Borrowed',
                                            'rejected' => 'Denied',
                                            'returned' => 'Successfully Returned',
                                        ];
                                    @endphp
                                    <span class="px-2 py-1 rounded-full text-[9px] font-black uppercase tracking-tight {{ $statusClasses[$borrow->status] ?? 'bg-gray-100' }}">
                                        {{ $statusLabels[$borrow->status] ?? $borrow->status }}
                                    </span>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="space-y-1">
                                        @if($borrow->borrowed_at)
                                            <div class="text-[9px]"><span class="text-gray-400">Borrowed:</span> {{ $borrow->borrowed_at->format('M d, Y') }}</div>
                                        @endif
                                        <div class="text-[9px] font-bold {{ $borrow->status === 'returned' ? 'text-green-600' : (now() > $borrow->due_at ? 'text-red-600' : 'text-amber-600') }}">
                                            <span class="text-gray-400 font-normal italic">Expected Return:</span> {{ $borrow->due_at->format('M d, Y') }}
                                        </div>
                                        @if($borrow->current_fine > 0)
                                            <div class="flex items-center space-x-1">
                                                <span class="text-[10px] font-black text-red-600">₱{{ number_format($borrow->current_fine, 2) }}</span>
                                                @if($borrow->is_fine_paid)
                                                    <span class="bg-green-600 text-white text-[7px] px-1 rounded px-1">PAID</span>
                                                @else
                                                    <form action="{{ route('borrowings.pay-fine', $borrow) }}" method="POST" class="inline">
                                                        @csrf
                                                        <button type="submit" class="bg-amber-100 text-amber-700 text-[8px] font-bold px-1 rounded border border-amber-200">PAY</button>
                                                    </form>
                                                @endif
                                            </div>
                                        @endif
                                    </div>
                                </td>
                                <td class="px-6 py-4 text-right">
                                    @if($borrow->status === 'approved')
                                        <form action="{{ route('borrowings.acknowledge-return', $borrow) }}" method="POST">
                                            @csrf
                                            <button type="submit" class="bg-purple-50 text-purple-600 border border-purple-200 px-3 py-1 rounded text-[9px] font-bold hover:bg-purple-100 transition-all uppercase">Direct Return</button>
                                        </form>
                                    @else
                                        <div class="text-[10px] text-gray-300 italic font-medium">Logged in System</div>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="px-6 py-4 text-center text-gray-500 text-sm">No transaction records found in history.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </x-premium-card>
    </div>
</x-app-layout>
