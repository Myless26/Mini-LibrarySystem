<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-purple-800 leading-tight">
                {{ __('Book Details: ') }} {{ $book->title }}
            </h2>
            <a href="{{ route('books.index') }}" class="text-purple-600 hover:text-purple-900 font-bold">← Back to Inventory</a>
        </div>
    </x-slot>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-1 space-y-6">
            <x-premium-card title="Book Info">
                <div class="space-y-4">
                    <div>
                        <span class="text-gray-500 text-xs uppercase">ISBN</span>
                        <p class="font-bold tracking-widest">{{ $book->isbn }}</p>
                    </div>
                    <div>
                        <span class="text-gray-500 text-xs uppercase">Authors</span>
                        <div class="mt-1 flex flex-wrap gap-2">
                            @foreach($book->authors as $author)
                                <span class="px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs font-bold">{{ $author->name }}</span>
                            @endforeach
                        </div>
                    </div>
                    <div>
                        <span class="text-gray-500 text-xs uppercase">Available Stock</span>
                        <p class="text-2xl font-black text-purple-800">{{ $book->available_stock }} / {{ $book->total_stock }}</p>
                    </div>
                </div>
            </x-premium-card>
        </div>

        <div class="lg:col-span-2">
            <x-premium-card title="Recent Borrowers">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-purple-100">
                        <thead class="bg-purple-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Student</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Borrowed</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Status</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-100">
                            @forelse($book->borrowings()->with('student')->latest()->take(10)->get() as $borrow)
                                <tr>
                                    <td class="px-6 py-4">
                                        <div class="text-sm font-bold text-gray-900">{{ $borrow->student->name }}</div>
                                        <div class="text-[10px] text-gray-400">{{ $borrow->student->email }}</div>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-600">
                                        {{ $borrow->borrowed_at->format('M d, Y') }}
                                    </td>
                                    <td class="px-6 py-4">
                                        @if($borrow->returned_at)
                                            <span class="text-green-600 font-bold text-xs">Returned</span>
                                        @else
                                            <span class="text-amber-600 font-bold text-xs">Active</span>
                                        @endif
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="3" class="px-6 py-4 text-center text-gray-500 italic">No borrowing history.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </x-premium-card>
        </div>
    </div>
</x-app-layout>
