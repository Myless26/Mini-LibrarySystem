<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');

    Route::resource('authors', \App\Http\Controllers\AuthorController::class);
    Route::resource('books', \App\Http\Controllers\BookController::class);
    Route::resource('students', \App\Http\Controllers\StudentController::class);
    Route::resource('users', \App\Http\Controllers\UserController::class)->only(['index']);
    
    Route::get('archive', [\App\Http\Controllers\ArchiveController::class, 'index'])->name('archive.index');
    Route::post('archive/restore/{type}/{id}', [\App\Http\Controllers\ArchiveController::class, 'restore'])->name('archive.restore');
    Route::delete('archive/delete/{type}/{id}', [\App\Http\Controllers\ArchiveController::class, 'forceDelete'])->name('archive.force-delete');

    Route::get('borrowings', [\App\Http\Controllers\BorrowingController::class, 'index'])->name('borrowings.index');
    Route::get('borrowings/create', [\App\Http\Controllers\BorrowingController::class, 'create'])->name('borrowings.create');
    Route::post('borrowings', [\App\Http\Controllers\BorrowingController::class, 'store'])->name('borrowings.store');
    Route::post('borrowings/{borrowing}/approve', [\App\Http\Controllers\BorrowingController::class, 'approve'])->name('borrowings.approve');
    Route::post('borrowings/{borrowing}/reject', [\App\Http\Controllers\BorrowingController::class, 'reject'])->name('borrowings.reject');
    Route::post('borrowings/{borrowing}/request-return', [\App\Http\Controllers\BorrowingController::class, 'requestReturn'])->name('borrowings.request-return');
    Route::post('borrowings/{borrowing}/acknowledge-return', [\App\Http\Controllers\BorrowingController::class, 'acknowledgeReturn'])->name('borrowings.acknowledge-return');
    Route::post('borrowings/{borrowing}/pay-fine', [\App\Http\Controllers\BorrowingController::class, 'payFine'])->name('borrowings.pay-fine');

    Route::get('my-borrowings', [\App\Http\Controllers\MyBorrowingController::class, 'index'])->name('my-borrowings.index');

    Route::get('notifications/{id}/read', function ($id) {
        $notification = auth()->user()->notifications()->findOrFail($id);
        $notification->markAsRead();
        return redirect($notification->data['action_url'] ?? route('dashboard'));
    })->name('notifications.read');

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
