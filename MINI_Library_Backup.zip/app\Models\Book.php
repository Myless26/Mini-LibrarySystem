<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Book extends Model
{
    use SoftDeletes;
    protected $fillable = ['title', 'isbn', 'total_stock', 'available_stock'];

    public function authors()
    {
        return $this->belongsToMany(Author::class);
    }

    public function borrowings()
    {
        return $this->hasMany(Borrowing::class);
    }
}
