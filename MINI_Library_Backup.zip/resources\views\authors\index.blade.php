<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-purple-800 leading-tight">
                {{ __('Authors') }}
            </h2>
            @if(auth()->check() && auth()->user()->isAdmin())
            <a href="{{ route('authors.create') }}" class="inline-flex items-center px-4 py-2 bg-purple-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-purple-700 active:bg-purple-900 focus:outline-none focus:border-purple-900 focus:ring ring-purple-300 disabled:opacity-25 transition ease-in-out duration-150">
                + Add Author
            </a>
            @endif
        </div>
    </x-slot>

    <x-premium-card title="List of Authors">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-purple-100">
                <thead class="bg-purple-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Bio</th>
                        @if(auth()->check() && auth()->user()->isAdmin())
                        <th class="px-6 py-3 text-right text-xs font-medium text-purple-700 uppercase tracking-wider">Actions</th>
                        @endif
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-100">
                    @forelse($authors as $author)
                        <tr class="hover:bg-purple-50/50 transition-colors">
                            <td class="px-6 py-4 whitespace-nowrap font-medium text-gray-900">{{ $author->name }}</td>
                            <td class="px-6 py-4 text-gray-600 truncate max-w-xs">{{ $author->bio }}</td>
                            @if(auth()->check() && auth()->user()->isAdmin())
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <a href="{{ route('authors.edit', $author) }}" class="text-purple-600 hover:text-purple-900 mr-3">Edit</a>
                                <form x-data action="{{ route('authors.destroy', $author) }}" method="POST" class="inline" x-ref="deleteForm{{ $author->id }}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="button" class="text-red-600 hover:text-red-900" 
                                            @click="$dispatch('confirm', { 
                                                title: 'Delete Author?', 
                                                message: 'Are you sure you want to remove this author? This action cannot be undone.',
                                                action: () => $refs.deleteForm{{ $author->id }}.submit()
                                            })">
                                        Delete
                                    </button>
                                </form>
                            </td>
                            @endif
                        </tr>
                    @empty
                        <tr>
                            <td colspan="3" class="px-6 py-4 text-center text-gray-500">No authors found.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </x-premium-card>
</x-app-layout>
