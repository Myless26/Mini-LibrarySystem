<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-purple-800 leading-tight">
                {{ __('Author Details: ') }} {{ $author->name }}
            </h2>
            <a href="{{ route('authors.index') }}" class="text-purple-600 hover:text-purple-900 font-bold">← Back to List</a>
        </div>
    </x-slot>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-1">
            <x-premium-card title="Author Bio">
                <p class="text-gray-700 leading-relaxed italic">
                    {{ $author->bio ?? 'No biography available.' }}
                </p>
            </x-premium-card>
        </div>

        <div class="lg:col-span-2">
            <x-premium-card title="Books by this Author">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    @forelse($author->books as $book)
                        <div class="p-4 rounded-xl border border-purple-100 bg-purple-50/50 hover:bg-white transition-all shadow-sm">
                            <h4 class="font-black text-purple-900">{{ $book->title }}</h4>
                            <p class="text-xs text-gray-500">ISBN: {{ $book->isbn }}</p>
                            <div class="mt-2 flex items-center justify-between">
                                <span class="text-xs font-bold {{ $book->available_stock > 0 ? 'text-green-600' : 'text-red-600' }}">
                                    {{ $book->available_stock }} copies left
                                </span>
                                <a href="{{ route('books.show', $book) }}" class="text-[10px] uppercase font-black text-purple-600 hover:underline">View Book</a>
                            </div>
                        </div>
                    @empty
                        <p class="text-gray-500 italic">No books recorded for this author.</p>
                    @endforelse
                </div>
            </x-premium-card>
        </div>
    </div>
</x-app-layout>
