<svg {{ $attributes }} viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" shape-rendering="crispEdges" style="image-rendering: pixelated;">
    <!-- Back Cover/Shadow -->
    <path fill="#3a2208" d="M12 3h1v10h-1z" />
    <path fill="#2c1a06" d="M11 2h2v12h-2z" />
    
    <!-- Main Cover -->
    <path fill="#804b19" d="M3 2h9v12H3z" />
    
    <!-- Borders -->
    <path fill="#543110" d="M2 1h11v1H2z M2 14h11v1H2z M13 2h1v12h-1z M2 2h1v12H2z" />
    
    <!-- Spine Detail -->
    <path fill="#2c1a06" d="M3 2h2v12H3z" />
    <path fill="#543110" d="M5 2h1v12H5z" />

    <!-- Pages Edge -->
    <path fill="#ffe8c9" d="M11 2h1v11h-1z" />
    <path fill="#e6cdad" d="M10 2h1v10h-1z" />
    
    <!-- Ribbon -->
    <path fill="#bb2929" d="M6 2h1v6H6z" />
    <path fill="#e6cdad" d="M6 7h1v1H6z" />
    <path fill="#991f1f" d="M6 8h1v1H6z" />
    
    <!-- Cover Detail / Decoration -->
    <path fill="#a36326" d="M7 4h2v1H7z M7 6h2v1H7z M7 10h3v1H7z M7 12h2v1H7z" />
</svg>
