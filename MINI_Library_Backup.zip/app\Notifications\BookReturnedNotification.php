<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use App\Models\Borrowing;

class BookReturnedNotification extends Notification
{
    use Queueable;

    public $borrowing;

    public function __construct(Borrowing $borrowing)
    {
        $this->borrowing = $borrowing;
    }

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toDatabase(object $notifiable): array
    {
        $actor = $this->borrowing->student->name;
        $book = $this->borrowing->book->title;
        $status = $this->borrowing->status;
        $fineMsg = $this->borrowing->fine_amount > 0 ? " A fine of ₱{$this->borrowing->fine_amount} was incurred." : "";

        $title = $status === Borrowing::STATUS_RETURN_PENDING ? 'Return Request' : 'Return Acknowledged';
        $message = $status === Borrowing::STATUS_RETURN_PENDING
            ? "{$actor} wants to return '{$book}'."
            : "Return of '{$book}' has been acknowledged by Admin.{$fineMsg}";

        return [
            'title' => $title,
            'message' => $message,
            'action_url' => route(auth()->user() && auth()->user()->isAdmin() ? 'borrowings.index' : 'my-borrowings.index'),
            'icon' => $status === Borrowing::STATUS_RETURN_PENDING ? 'arrow-path' : 'check-double'
        ];
    }
}
