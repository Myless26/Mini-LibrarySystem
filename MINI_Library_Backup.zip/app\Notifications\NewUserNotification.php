<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use App\Models\User;

class NewUserNotification extends Notification
{
    use Queueable;

    public $newUser;

    public function __construct(User $newUser)
    {
        $this->newUser = $newUser;
    }

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toDatabase(object $notifiable): array
    {
        return [
            'title' => 'New User Registered',
            'message' => "{$this->newUser->name} ({$this->newUser->email}) has joined the system.",
            'action_url' => route('users.index'),
            'icon' => 'user-plus'
        ];
    }
}
