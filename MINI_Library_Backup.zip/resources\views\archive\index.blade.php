<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-purple-800 leading-tight">
            {{ __('Library Archive') }}
        </h2>
    </x-slot>

    <div class="space-y-10">
        {{-- Deleted Books --}}
        <x-premium-card title="Archived Books">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-purple-100">
                    <thead class="bg-purple-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Book Info</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Deleted At</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-purple-700 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-100">
                        @forelse($books as $book)
                            <tr>
                                <td class="px-6 py-4 font-bold text-gray-900">{{ $book->title }}</td>
                                <td class="px-6 py-4 text-xs text-gray-500">{{ $book->deleted_at->format('M d, Y H:i') }}</td>
                                <td class="px-6 py-4 text-right">
                                    <form action="{{ route('archive.restore', ['type' => 'book', 'id' => $book->id]) }}" method="POST" class="inline">
                                        @csrf
                                        <button type="submit" class="text-purple-600 hover:text-purple-900 font-bold text-xs mr-3 uppercase">Restore</button>
                                    </form>
                                    <form x-data action="{{ route('archive.force-delete', ['type' => 'book', 'id' => $book->id]) }}" method="POST" class="inline" x-ref="forceDeleteBook{{ $book->id }}">
                                        @csrf
                                        @method('DELETE')
                                        <button type="button" @click="$dispatch('confirm', { title: 'Permanent Delete?', message: 'This book will be gone forever!', action: () => $refs.forceDeleteBook{{ $book->id }}.submit() })" class="text-red-600 hover:text-red-900 font-bold text-xs uppercase">Purge</button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="3" class="px-6 py-4 text-center text-gray-400 italic">No deleted books.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </x-premium-card>

        {{-- Deleted Students --}}
        <x-premium-card title="Archived Students">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-purple-100">
                    <thead class="bg-purple-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Student</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Deleted At</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-purple-700 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-100">
                        @forelse($students as $student)
                            <tr>
                                <td class="px-6 py-4 font-bold text-gray-900">{{ $student->name }}</td>
                                <td class="px-6 py-4 text-xs text-gray-500">{{ $student->deleted_at->format('M d, Y H:i') }}</td>
                                <td class="px-6 py-4 text-right">
                                    <form action="{{ route('archive.restore', ['type' => 'student', 'id' => $student->id]) }}" method="POST" class="inline">
                                        @csrf
                                        <button type="submit" class="text-purple-600 hover:text-purple-900 font-bold text-xs mr-3 uppercase">Restore</button>
                                    </form>
                                    <form x-data action="{{ route('archive.force-delete', ['type' => 'student', 'id' => $student->id]) }}" method="POST" class="inline" x-ref="forceDeleteStudent{{ $student->id }}">
                                        @csrf
                                        @method('DELETE')
                                        <button type="button" @click="$dispatch('confirm', { title: 'Permanent Delete?', message: 'This student record will be gone forever!', action: () => $refs.forceDeleteStudent{{ $student->id }}.submit() })" class="text-red-600 hover:text-red-900 font-bold text-xs uppercase">Purge</button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="3" class="px-6 py-4 text-center text-gray-400 italic">No deleted students.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </x-premium-card>

        {{-- Deleted Authors --}}
        <x-premium-card title="Archived Authors">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-purple-100">
                    <thead class="bg-purple-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Author</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-purple-700 uppercase tracking-wider">Deleted At</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-purple-700 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-100">
                        @forelse($authors as $author)
                            <tr>
                                <td class="px-6 py-4 font-bold text-gray-900">{{ $author->name }}</td>
                                <td class="px-6 py-4 text-xs text-gray-500">{{ $author->deleted_at->format('M d, Y H:i') }}</td>
                                <td class="px-6 py-4 text-right">
                                    <form action="{{ route('archive.restore', ['type' => 'author', 'id' => $author->id]) }}" method="POST" class="inline">
                                        @csrf
                                        <button type="submit" class="text-purple-600 hover:text-purple-900 font-bold text-xs mr-3 uppercase">Restore</button>
                                    </form>
                                    <form x-data action="{{ route('archive.force-delete', ['type' => 'author', 'id' => $author->id]) }}" method="POST" class="inline" x-ref="forceDeleteAuthor{{ $author->id }}">
                                        @csrf
                                        @method('DELETE')
                                        <button type="button" @click="$dispatch('confirm', { title: 'Permanent Delete?', message: 'This author will be gone forever!', action: () => $refs.forceDeleteAuthor{{ $author->id }}.submit() })" class="text-red-600 hover:text-red-900 font-bold text-xs uppercase">Purge</button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="3" class="px-6 py-4 text-center text-gray-400 italic">No deleted authors.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </x-premium-card>
    </div>
</x-app-layout>
