<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Author;
use App\Models\Book;
use App\Models\Student;

class ArchiveController extends Controller
{
    public function index()
    {
        $authors = Author::onlyTrashed()->get();
        $books = Book::onlyTrashed()->get();
        $students = Student::onlyTrashed()->get();

        return view('archive.index', compact('authors', 'books', 'students'));
    }

    public function restore($type, $id)
    {
        $model = $this->getModel($type, $id);
        $model->restore();

        return redirect()->route('archive.index')->with('success', ucfirst($type) . ' restored successfully.');
    }

    public function forceDelete($type, $id)
    {
        $model = $this->getModel($type, $id);
        $model->forceDelete();

        return redirect()->route('archive.index')->with('success', ucfirst($type) . ' permanently deleted.');
    }

    protected function getModel($type, $id)
    {
        switch ($type) {
            case 'author': return Author::onlyTrashed()->findOrFail($id);
            case 'book': return Book::onlyTrashed()->findOrFail($id);
            case 'student': return Student::onlyTrashed()->findOrFail($id);
            default: abort(404);
        }
    }
}
