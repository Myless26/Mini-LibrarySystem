<div x-data="{ 
        show: false, 
        title: '', 
        message: '', 
        action: null,
        confirm(title, message, callback) {
            this.title = title;
            this.message = message;
            this.action = callback;
            this.show = true;
        },
        execute() {
            if (this.action) this.action();
            this.show = false;
        }
     }" 
     @confirm.window="confirm($event.detail.title, $event.detail.message, $event.detail.action)"
     x-show="show" 
     class="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-purple-900/60 backdrop-blur-sm"
     x-cloak
     x-transition:enter="transition ease-out duration-300"
     x-transition:enter-start="opacity-0 scale-95"
     x-transition:enter-end="opacity-100 scale-100"
     x-transition:leave="transition ease-in duration-200"
     x-transition:leave-start="opacity-100 scale-100"
     x-transition:leave-end="opacity-0 scale-95"
>
    <div class="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden border border-purple-100">
        <div class="p-6 text-center">
            <div class="mb-4 inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-50 text-red-600">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                </svg>
            </div>
            <h3 class="text-xl font-black text-gray-900 mb-2" x-text="title"></h3>
            <p class="text-gray-500 text-sm mb-8" x-text="message"></p>
            
            <div class="flex gap-3">
                <button @click="show = false" class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 font-bold rounded-xl hover:bg-gray-200 transition-colors">
                    Cancel
                </button>
                <button @click="execute()" class="flex-1 px-4 py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 shadow-lg shadow-red-200 transition-all active:scale-95">
                    Confirm
                </button>
            </div>
        </div>
    </div>
</div>
